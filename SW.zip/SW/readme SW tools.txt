note :
software is realized with Codewarrior rev 10.6
Project is done using processor expert libs