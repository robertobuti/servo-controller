/* ###################################################################
**     Filename    : main.c
**     Project     : servo controller
**     Processor   : MC9S08GT32CFB
**     Version     : Driver 01.12
**     Compiler    : CodeWarrior HCS08 C Compiler
**     Date/Time   : 2017-09-02, 09:58, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.12
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "KB1.h"
#include "PWM1.h"
#include "PWM2.h"
#include "PWM3.h"
#include "PWM4.h"
#include "IFsh1.h"
#include "LedRUN.h"
#include "LedServo0.h"
#include "LedServo1.h"
#include "LedServo2.h"
#include "LedServo3.h"
/* Include shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"


/* User includes (#include below this line is not maintained by Processor Expert) */
#define PWMmin 1000;	// minimum period for PWM
#define PWMmax 2000;	// maximum position
#define PWMSTEP 10;		// step increment / decrement

extern Servo1Min,Servo1Max,Servo2Min,Servo2Max,Servo3Min,Servo3Max,Servo4Min,Servo4Max;

void PwmUpdate (void);
void WriteFlash(void);

byte LEDrunCNT;			// counter for RTI interrupt for RUN led toggle 
byte LedServo[4];		// led servo status, 0 off, 1 on, 2 fast blink, 3 slow blink
byte LedServoCNT[4];	// counter for blink
byte event;				// event call
byte PGMbuttonCNT;		// counter PGM button
byte KB1val;			// keyboard values
unsigned int PwmValue[8];		// buffer for pwm values
unsigned char onlyforwarning,index,minmax,dummy;
unsigned int addr,data;

void main(void)
{
  /* Write your local variable definition here */

	LEDrunCNT = 40;
	LedServoCNT[0] = 10;
	LedServoCNT[1] = 10;
	LedServoCNT[2] = 10;
	LedServoCNT[3] = 10;
	PGMbuttonCNT = 0;

	
  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/
  
  PwmValue[0] = Servo1Min;
  PwmValue[1] = Servo1Max;
  PwmValue[2] = Servo2Min;
  PwmValue[3] = Servo2Max;
  PwmValue[4] = Servo3Min;
  PwmValue[5] = Servo3Max;
  PwmValue[6] = Servo4Min;
  PwmValue[7] = Servo4Max;
    
  onlyforwarning = PWM1_SetDutyUS(PwmValue[0]);	// update position
  onlyforwarning = PWM2_SetDutyUS(PwmValue[2]);	// update position
  onlyforwarning = PWM3_SetDutyUS(PwmValue[4]);	// update position
  onlyforwarning = PWM4_SetDutyUS(PwmValue[6]);	// update position
  
  LedServo0_SetVal();
  LedServo1_SetVal();
  LedServo2_SetVal();
  LedServo3_SetVal();
    
  /* Write your code here */
  for(;;) { 
	  if ((event & 0x01))	// event call each 20mS
	  {
	  event &= 0x7e; 	// clear flag
	  switch (LedServo[0])		// Servo 0 led status update
					   {
					   case 0:	// led OFF	
						   LedServo0_SetVal();
						   break;
					   case 1:	// Led ON
						   LedServo0_ClrVal();
						   break;
					   case 2:	// fast blink
					   	   {
					   		if (LedServoCNT[0] )
					   			LedServoCNT[0]--;		
					   		else
					   			{  		  
					   			LedServoCNT[0] = 10;
					   			LedServo0_NegVal();
					   			}
					   	   }
					   	   break;
					   }
	  switch (LedServo[1])		// Servo 1 led status update
					   {
					   case 0:	// led OFF	
						   LedServo1_SetVal();
						   break;
					   case 1:	// Led ON
						   LedServo1_ClrVal();
						   break;
					   case 2:	// fast blink
					   	   {
					   		if (LedServoCNT[1] )
					   			LedServoCNT[1]--;		
					   		else
					   			{  		  
					   			LedServoCNT[1] = 10;
					   			LedServo1_NegVal();
					   			}
					   	   }
					   	   break;
					   }
	  switch (LedServo[2])		// Servo 2 led status update
					   {
					   case 0:	// led OFF	
						   LedServo2_SetVal();
						   break;
					   case 1:	// Led ON
						   LedServo2_ClrVal();
						   break;
					   case 2:	// fast blink
					   	   {
					   		if (LedServoCNT[2] )
					   			LedServoCNT[2]--;		
					   		else
					   			{  		  
					   			LedServoCNT[2] = 10;
					   			LedServo2_NegVal();
					   			}
					   	   }
					   	   break;
					   }	  
	  switch (LedServo[3])		// Servo 3 led status update
					   {
					   case 0:	// led OFF	
						   LedServo3_SetVal();
						   break;
					   case 1:	// Led ON
						   LedServo3_ClrVal();
						   break;
					   case 2:	// fast blink
					   	   {
					   		if (LedServoCNT[3] )
					   			LedServoCNT[3]--;		
					   		else
					   			{  		  
					   			LedServoCNT[3] = 10;
					   			LedServo3_NegVal();
					   			}
					   	   }
					   	   break;
					   }
	  
// test for PGM mode ?
	  	  KB1val = ~KB1_GetVal();	// get value, 1= button pressed
	  	  KB1val &= 0x7f;
	  			  
		  if ((event & 0x02))	// event KB1 pressed 
			  {
			  if (KB1val == 0x40)	// PGM button pressed 
				  {
				  event &= 0x7d; 	// clear flag
				  if (PGMbuttonCNT == 0)
					  PGMbuttonCNT = 150;		// start counter 3" to enter or exit PGM mode
				  else
					  PGMbuttonCNT = 0;			
				  }
			  
// programmation management
			  if (KB1val & 0x0f) 		// button servo ? (binay value 0x 1/2/4/8)
				  {
				  index = KB1val >> 1;			// used as index in up/ down button
				  event &= 0x7d; 	// clear flag	
				  if (index == 0x04)
					  index = 3;				// binary to decimal
				  if (minmax == 0)
					  {
					  minmax = 1;  	// togle min / max
					  LedServo[index] = 1;		// led servo ON
					  }
				  else
					  {
					  minmax = 0;
					  LedServo[index] = 0;		// led servo OFF				  
					  }
				  PwmUpdate();
				  KB1val = 0;
				  }
			  }
// end button on event		
		  if (PGMbuttonCNT)
		  	  {
			  if (KB1val == 0x40)	// PGM still button pressed ?
				  {
				  PGMbuttonCNT--;
				  if (PGMbuttonCNT == 0)
					  {
					  if ((event & 0x04) == 0) // if not in PGM mode set it
						  {
						  event |= 0x4;		// PGM mode
						  LedServo[0] = 2;	// all servo led fast blink
						  LedServo[1] = 2;
						  LedServo[2] = 2;
						  LedServo[3] = 2;
						  LedServo0_SetVal();		// all led off to have syncro blink
						  LedServo1_SetVal();
						  LedServo2_SetVal();
						  LedServo3_SetVal();
						  }
					  else
						  {
						  event = 0;	// clear all PGM mode off
						  LedServo[0] = 0;	// all servo led off
						  LedServo[1] = 0;
						  LedServo[2] = 0;
						  LedServo[3] = 0;
						  WriteFlash();
						  PGMbuttonCNT = 0;
						  }
					  }			 
				  }
			  else
				  PGMbuttonCNT == 0;	// too short time				  
		  	  }
		  
		  if (event & 0x04)	// if PGM mode then manage it
			  {
			  if (KB1val == 0x10)		// button uP
				  {			  
				  event &= 0x7d; 	// clear flag	
				  if (PwmValue[(index<<1) + minmax] <= 2000)
				  	  {
					  PwmValue[(index<<1) + minmax] = PwmValue[(index<<1) + minmax] + PWMSTEP; //increment
					  PwmUpdate();
				  	  }
				  }		  
			  if (KB1val == 0x20)		// button down
				  {			  
				  event &= 0x7d; 	// clear flag	
				  if (PwmValue[(index<<1) + minmax] >= 1000)
				  	  {
					  PwmValue[(index<<1) + minmax] = PwmValue[(index<<1) + minmax] - PWMSTEP; //increment
					  PwmUpdate();
				  	  }
				  }

			  KB1val = 0;
			  }		  
  }
 }
  
 

  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

void PwmUpdate(void)
	{
	  if (index == 0)
		  onlyforwarning = PWM1_SetDutyUS(PwmValue[0 + minmax]);	// update position
	  if (index == 1)
		  onlyforwarning = PWM2_SetDutyUS(PwmValue[2 + minmax]);	// update position				  
	  if (index == 2)
		  onlyforwarning = PWM3_SetDutyUS(PwmValue[4 + minmax]);	// update position
	  if (index == 3)
		  onlyforwarning = PWM4_SetDutyUS(PwmValue[6 + minmax]);	// update position
	}
void WriteFlash(void)
	{
	char i;
	IFsh1_EraseSector(0x8000);
		i = 0;
		while (i < 8)
			{
			addr = 0x8000 + (i << 1);	// calculate addr
			data = PwmValue[i];		// get value
			onlyforwarning = IFsh1_SetWordFlash(addr,data);
			i ++;
			}
		}
/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.3 [05.09]
**     for the Freescale HCS08 series of microcontrollers.
**
** ###################################################################
*/
